const config = {
    token: null,
    baseURL: null
}